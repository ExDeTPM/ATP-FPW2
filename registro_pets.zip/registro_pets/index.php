<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Inicial</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Bem-vindo aos registros da ONG "Pelos, Patas, Bicos e Escamas"</h1>
    <p>Novo por aqui? <a href="cadastro.php">Cadastre-se!</a></p>
    <p>Já é de casa? <a href="login.php">Login!</a></p>
    </form>
    <footer>
    <div class="footer-content">
        <p>&copy; 2024 Pelos, Patas, Bicos e Escamas. Todos os direitos reservados.</p>
        <nav class="footer-nav">
        </nav>
    </div>
</footer>
</body>
</html>